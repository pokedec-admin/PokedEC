import{a as dt,b as ft,c as pt,f as Z}from"./chunk-6E4Y4CSF.js";import{a as gt}from"./chunk-MNCI3543.js";import"./chunk-PST5FIHU.js";import{L as st,P as at,Q as lt,R as ot,S as ct,T as ht,U as ut,V as yt,W as F}from"./chunk-FT3GWW7A.js";import{H as U,b as n,j as W}from"./chunk-AXNNVVFI.js";import"./chunk-TMCOXDIZ.js";var K=function(){var t=n(function(h,r,a,l){for(a=a||{},l=h.length;l--;a[h[l]]=r);return a},"o"),e=[6,8,10,11,12,14,16,17,18],s=[1,9],c=[1,10],i=[1,11],f=[1,12],u=[1,13],d=[1,14],g={trace:n(function(){},"trace"),yy:{},symbols_:{error:2,start:3,journey:4,document:5,EOF:6,line:7,SPACE:8,statement:9,NEWLINE:10,title:11,acc_title:12,acc_title_value:13,acc_descr:14,acc_descr_value:15,acc_descr_multiline_value:16,section:17,taskName:18,taskData:19,$accept:0,$end:1},terminals_:{2:"error",4:"journey",6:"EOF",8:"SPACE",10:"NEWLINE",11:"title",12:"acc_title",13:"acc_title_value",14:"acc_descr",15:"acc_descr_value",16:"acc_descr_multiline_value",17:"section",18:"taskName",19:"taskData"},productions_:[0,[3,3],[5,0],[5,2],[7,2],[7,1],[7,1],[7,1],[9,1],[9,2],[9,2],[9,1],[9,1],[9,2]],performAction:n(function(r,a,l,y,p,o,v){var k=o.length-1;switch(p){case 1:return o[k-1];case 2:this.$=[];break;case 3:o[k-1].push(o[k]),this.$=o[k-1];break;case 4:case 5:this.$=o[k];break;case 6:case 7:this.$=[];break;case 8:y.setDiagramTitle(o[k].substr(6)),this.$=o[k].substr(6);break;case 9:this.$=o[k].trim(),y.setAccTitle(this.$);break;case 10:case 11:this.$=o[k].trim(),y.setAccDescription(this.$);break;case 12:y.addSection(o[k].substr(8)),this.$=o[k].substr(8);break;case 13:y.addTask(o[k-1],o[k]),this.$="task";break}},"anonymous"),table:[{3:1,4:[1,2]},{1:[3]},t(e,[2,2],{5:3}),{6:[1,4],7:5,8:[1,6],9:7,10:[1,8],11:s,12:c,14:i,16:f,17:u,18:d},t(e,[2,7],{1:[2,1]}),t(e,[2,3]),{9:15,11:s,12:c,14:i,16:f,17:u,18:d},t(e,[2,5]),t(e,[2,6]),t(e,[2,8]),{13:[1,16]},{15:[1,17]},t(e,[2,11]),t(e,[2,12]),{19:[1,18]},t(e,[2,4]),t(e,[2,9]),t(e,[2,10]),t(e,[2,13])],defaultActions:{},parseError:n(function(r,a){if(a.recoverable)this.trace(r);else{var l=new Error(r);throw l.hash=a,l}},"parseError"),parse:n(function(r){var a=this,l=[0],y=[],p=[null],o=[],v=this.table,k="",C=0,tt=0,et=0,$t=2,rt=1,Mt=o.slice.call(arguments,1),b=Object.create(this.lexer),I={yy:{}};for(var Y in this.yy)Object.prototype.hasOwnProperty.call(this.yy,Y)&&(I.yy[Y]=this.yy[Y]);b.setInput(r,I.yy),I.yy.lexer=b,I.yy.parser=this,typeof b.yylloc>"u"&&(b.yylloc={});var q=b.yylloc;o.push(q);var Et=b.options&&b.options.ranges;typeof I.yy.parseError=="function"?this.parseError=I.yy.parseError:this.parseError=Object.getPrototypeOf(this).parseError;function Ct(w){l.length=l.length-2*w,p.length=p.length-w,o.length=o.length-w}n(Ct,"popStack");function it(){var w;return w=y.pop()||b.lex()||rt,typeof w!="number"&&(w instanceof Array&&(y=w,w=y.pop()),w=a.symbols_[w]||w),w}n(it,"lex");for(var _,X,A,T,Jt,G,V={},N,M,nt,z;;){if(A=l[l.length-1],this.defaultActions[A]?T=this.defaultActions[A]:((_===null||typeof _>"u")&&(_=it()),T=v[A]&&v[A][_]),typeof T>"u"||!T.length||!T[0]){var H="";z=[];for(N in v[A])this.terminals_[N]&&N>$t&&z.push("'"+this.terminals_[N]+"'");b.showPosition?H="Parse error on line "+(C+1)+`:
`+b.showPosition()+`
Expecting `+z.join(", ")+", got '"+(this.terminals_[_]||_)+"'":H="Parse error on line "+(C+1)+": Unexpected "+(_==rt?"end of input":"'"+(this.terminals_[_]||_)+"'"),this.parseError(H,{text:b.match,token:this.terminals_[_]||_,line:b.yylineno,loc:q,expected:z})}if(T[0]instanceof Array&&T.length>1)throw new Error("Parse Error: multiple actions possible at state: "+A+", token: "+_);switch(T[0]){case 1:l.push(_),p.push(b.yytext),o.push(b.yylloc),l.push(T[1]),_=null,X?(_=X,X=null):(tt=b.yyleng,k=b.yytext,C=b.yylineno,q=b.yylloc,et>0&&et--);break;case 2:if(M=this.productions_[T[1]][1],V.$=p[p.length-M],V._$={first_line:o[o.length-(M||1)].first_line,last_line:o[o.length-1].last_line,first_column:o[o.length-(M||1)].first_column,last_column:o[o.length-1].last_column},Et&&(V._$.range=[o[o.length-(M||1)].range[0],o[o.length-1].range[1]]),G=this.performAction.apply(V,[k,tt,C,I.yy,T[1],p,o].concat(Mt)),typeof G<"u")return G;M&&(l=l.slice(0,-1*M*2),p=p.slice(0,-1*M),o=o.slice(0,-1*M)),l.push(this.productions_[T[1]][0]),p.push(V.$),o.push(V._$),nt=v[l[l.length-2]][l[l.length-1]],l.push(nt);break;case 3:return!0}}return!0},"parse")},m=function(){var h={EOF:1,parseError:n(function(a,l){if(this.yy.parser)this.yy.parser.parseError(a,l);else throw new Error(a)},"parseError"),setInput:n(function(r,a){return this.yy=a||this.yy||{},this._input=r,this._more=this._backtrack=this.done=!1,this.yylineno=this.yyleng=0,this.yytext=this.matched=this.match="",this.conditionStack=["INITIAL"],this.yylloc={first_line:1,first_column:0,last_line:1,last_column:0},this.options.ranges&&(this.yylloc.range=[0,0]),this.offset=0,this},"setInput"),input:n(function(){var r=this._input[0];this.yytext+=r,this.yyleng++,this.offset++,this.match+=r,this.matched+=r;var a=r.match(/(?:\r\n?|\n).*/g);return a?(this.yylineno++,this.yylloc.last_line++):this.yylloc.last_column++,this.options.ranges&&this.yylloc.range[1]++,this._input=this._input.slice(1),r},"input"),unput:n(function(r){var a=r.length,l=r.split(/(?:\r\n?|\n)/g);this._input=r+this._input,this.yytext=this.yytext.substr(0,this.yytext.length-a),this.offset-=a;var y=this.match.split(/(?:\r\n?|\n)/g);this.match=this.match.substr(0,this.match.length-1),this.matched=this.matched.substr(0,this.matched.length-1),l.length-1&&(this.yylineno-=l.length-1);var p=this.yylloc.range;return this.yylloc={first_line:this.yylloc.first_line,last_line:this.yylineno+1,first_column:this.yylloc.first_column,last_column:l?(l.length===y.length?this.yylloc.first_column:0)+y[y.length-l.length].length-l[0].length:this.yylloc.first_column-a},this.options.ranges&&(this.yylloc.range=[p[0],p[0]+this.yyleng-a]),this.yyleng=this.yytext.length,this},"unput"),more:n(function(){return this._more=!0,this},"more"),reject:n(function(){if(this.options.backtrack_lexer)this._backtrack=!0;else return this.parseError("Lexical error on line "+(this.yylineno+1)+`. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
`+this.showPosition(),{text:"",token:null,line:this.yylineno});return this},"reject"),less:n(function(r){this.unput(this.match.slice(r))},"less"),pastInput:n(function(){var r=this.matched.substr(0,this.matched.length-this.match.length);return(r.length>20?"...":"")+r.substr(-20).replace(/\n/g,"")},"pastInput"),upcomingInput:n(function(){var r=this.match;return r.length<20&&(r+=this._input.substr(0,20-r.length)),(r.substr(0,20)+(r.length>20?"...":"")).replace(/\n/g,"")},"upcomingInput"),showPosition:n(function(){var r=this.pastInput(),a=new Array(r.length+1).join("-");return r+this.upcomingInput()+`
`+a+"^"},"showPosition"),test_match:n(function(r,a){var l,y,p;if(this.options.backtrack_lexer&&(p={yylineno:this.yylineno,yylloc:{first_line:this.yylloc.first_line,last_line:this.last_line,first_column:this.yylloc.first_column,last_column:this.yylloc.last_column},yytext:this.yytext,match:this.match,matches:this.matches,matched:this.matched,yyleng:this.yyleng,offset:this.offset,_more:this._more,_input:this._input,yy:this.yy,conditionStack:this.conditionStack.slice(0),done:this.done},this.options.ranges&&(p.yylloc.range=this.yylloc.range.slice(0))),y=r[0].match(/(?:\r\n?|\n).*/g),y&&(this.yylineno+=y.length),this.yylloc={first_line:this.yylloc.last_line,last_line:this.yylineno+1,first_column:this.yylloc.last_column,last_column:y?y[y.length-1].length-y[y.length-1].match(/\r?\n?/)[0].length:this.yylloc.last_column+r[0].length},this.yytext+=r[0],this.match+=r[0],this.matches=r,this.yyleng=this.yytext.length,this.options.ranges&&(this.yylloc.range=[this.offset,this.offset+=this.yyleng]),this._more=!1,this._backtrack=!1,this._input=this._input.slice(r[0].length),this.matched+=r[0],l=this.performAction.call(this,this.yy,this,a,this.conditionStack[this.conditionStack.length-1]),this.done&&this._input&&(this.done=!1),l)return l;if(this._backtrack){for(var o in p)this[o]=p[o];return!1}return!1},"test_match"),next:n(function(){if(this.done)return this.EOF;this._input||(this.done=!0);var r,a,l,y;this._more||(this.yytext="",this.match="");for(var p=this._currentRules(),o=0;o<p.length;o++)if(l=this._input.match(this.rules[p[o]]),l&&(!a||l[0].length>a[0].length)){if(a=l,y=o,this.options.backtrack_lexer){if(r=this.test_match(l,p[o]),r!==!1)return r;if(this._backtrack){a=!1;continue}else return!1}else if(!this.options.flex)break}return a?(r=this.test_match(a,p[y]),r!==!1?r:!1):this._input===""?this.EOF:this.parseError("Lexical error on line "+(this.yylineno+1)+`. Unrecognized text.
`+this.showPosition(),{text:"",token:null,line:this.yylineno})},"next"),lex:n(function(){var a=this.next();return a||this.lex()},"lex"),begin:n(function(a){this.conditionStack.push(a)},"begin"),popState:n(function(){var a=this.conditionStack.length-1;return a>0?this.conditionStack.pop():this.conditionStack[0]},"popState"),_currentRules:n(function(){return this.conditionStack.length&&this.conditionStack[this.conditionStack.length-1]?this.conditions[this.conditionStack[this.conditionStack.length-1]].rules:this.conditions.INITIAL.rules},"_currentRules"),topState:n(function(a){return a=this.conditionStack.length-1-Math.abs(a||0),a>=0?this.conditionStack[a]:"INITIAL"},"topState"),pushState:n(function(a){this.begin(a)},"pushState"),stateStackSize:n(function(){return this.conditionStack.length},"stateStackSize"),options:{"case-insensitive":!0},performAction:n(function(a,l,y,p){var o=p;switch(y){case 0:break;case 1:break;case 2:return 10;case 3:break;case 4:break;case 5:return 4;case 6:return 11;case 7:return this.begin("acc_title"),12;break;case 8:return this.popState(),"acc_title_value";break;case 9:return this.begin("acc_descr"),14;break;case 10:return this.popState(),"acc_descr_value";break;case 11:this.begin("acc_descr_multiline");break;case 12:this.popState();break;case 13:return"acc_descr_multiline_value";case 14:return 17;case 15:return 18;case 16:return 19;case 17:return":";case 18:return 6;case 19:return"INVALID"}},"anonymous"),rules:[/^(?:%(?!\{)[^\n]*)/i,/^(?:[^\}]%%[^\n]*)/i,/^(?:[\n]+)/i,/^(?:\s+)/i,/^(?:#[^\n]*)/i,/^(?:journey\b)/i,/^(?:title\s[^#\n;]+)/i,/^(?:accTitle\s*:\s*)/i,/^(?:(?!\n||)*[^\n]*)/i,/^(?:accDescr\s*:\s*)/i,/^(?:(?!\n||)*[^\n]*)/i,/^(?:accDescr\s*\{\s*)/i,/^(?:[\}])/i,/^(?:[^\}]*)/i,/^(?:section\s[^#:\n;]+)/i,/^(?:[^#:\n;]+)/i,/^(?::[^#\n;]+)/i,/^(?::)/i,/^(?:$)/i,/^(?:.)/i],conditions:{acc_descr_multiline:{rules:[12,13],inclusive:!1},acc_descr:{rules:[10],inclusive:!1},acc_title:{rules:[8],inclusive:!1},INITIAL:{rules:[0,1,2,3,4,5,6,7,9,11,14,15,16,17,18,19],inclusive:!0}}};return h}();g.lexer=m;function x(){this.yy={}}return n(x,"Parser"),x.prototype=g,g.Parser=x,new x}();K.parser=K;var Pt=K,R="",Q=[],L=[],B=[],It=n(function(){Q.length=0,L.length=0,R="",B.length=0,at()},"clear"),At=n(function(t){R=t,Q.push(t)},"addSection"),Ft=n(function(){return Q},"getSections"),Vt=n(function(){let t=mt(),e=100,s=0;for(;!t&&s<e;)t=mt(),s++;return L.push(...B),L},"getTasks"),Rt=n(function(){let t=[];return L.forEach(s=>{s.people&&t.push(...s.people)}),[...new Set(t)].sort()},"updateActors"),Lt=n(function(t,e){let s=e.substr(1).split(":"),c=0,i=[];s.length===1?(c=Number(s[0]),i=[]):(c=Number(s[0]),i=s[1].split(","));let f=i.map(d=>d.trim()),u={section:R,type:R,people:f,task:t,score:c};B.push(u)},"addTask"),Bt=n(function(t){let e={section:R,type:R,description:t,task:t,classes:[]};L.push(e)},"addTaskOrg"),mt=n(function(){let t=n(function(s){return B[s].processed},"compileTask"),e=!0;for(let[s,c]of B.entries())t(s),e=e&&c.processed;return e},"compileTasks"),jt=n(function(){return Rt()},"getActors"),xt={getConfig:n(()=>F().journey,"getConfig"),clear:It,setDiagramTitle:ut,getDiagramTitle:yt,setAccTitle:lt,getAccTitle:ot,setAccDescription:ct,getAccDescription:ht,addSection:At,getSections:Ft,getTasks:Vt,addTask:Lt,addTaskOrg:Bt,getActors:jt},Nt=n(t=>`.label {
    font-family: ${t.fontFamily};
    color: ${t.textColor};
  }
  .mouth {
    stroke: #666;
  }

  line {
    stroke: ${t.textColor}
  }

  .legend {
    fill: ${t.textColor};
    font-family: ${t.fontFamily};
  }

  .label text {
    fill: #333;
  }
  .label {
    color: ${t.textColor}
  }

  .face {
    ${t.faceColor?`fill: ${t.faceColor}`:"fill: #FFF8DC"};
    stroke: #999;
  }

  .node rect,
  .node circle,
  .node ellipse,
  .node polygon,
  .node path {
    fill: ${t.mainBkg};
    stroke: ${t.nodeBorder};
    stroke-width: 1px;
  }

  .node .label {
    text-align: center;
  }
  .node.clickable {
    cursor: pointer;
  }

  .arrowheadPath {
    fill: ${t.arrowheadColor};
  }

  .edgePath .path {
    stroke: ${t.lineColor};
    stroke-width: 1.5px;
  }

  .flowchart-link {
    stroke: ${t.lineColor};
    fill: none;
  }

  .edgeLabel {
    background-color: ${t.edgeLabelBackground};
    rect {
      opacity: 0.5;
    }
    text-align: center;
  }

  .cluster rect {
  }

  .cluster text {
    fill: ${t.titleColor};
  }

  div.mermaidTooltip {
    position: absolute;
    text-align: center;
    max-width: 200px;
    padding: 2px;
    font-family: ${t.fontFamily};
    font-size: 12px;
    background: ${t.tertiaryColor};
    border: 1px solid ${t.border2};
    border-radius: 2px;
    pointer-events: none;
    z-index: 100;
  }

  .task-type-0, .section-type-0  {
    ${t.fillType0?`fill: ${t.fillType0}`:""};
  }
  .task-type-1, .section-type-1  {
    ${t.fillType0?`fill: ${t.fillType1}`:""};
  }
  .task-type-2, .section-type-2  {
    ${t.fillType0?`fill: ${t.fillType2}`:""};
  }
  .task-type-3, .section-type-3  {
    ${t.fillType0?`fill: ${t.fillType3}`:""};
  }
  .task-type-4, .section-type-4  {
    ${t.fillType0?`fill: ${t.fillType4}`:""};
  }
  .task-type-5, .section-type-5  {
    ${t.fillType0?`fill: ${t.fillType5}`:""};
  }
  .task-type-6, .section-type-6  {
    ${t.fillType0?`fill: ${t.fillType6}`:""};
  }
  .task-type-7, .section-type-7  {
    ${t.fillType0?`fill: ${t.fillType7}`:""};
  }

  .actor-0 {
    ${t.actor0?`fill: ${t.actor0}`:""};
  }
  .actor-1 {
    ${t.actor1?`fill: ${t.actor1}`:""};
  }
  .actor-2 {
    ${t.actor2?`fill: ${t.actor2}`:""};
  }
  .actor-3 {
    ${t.actor3?`fill: ${t.actor3}`:""};
  }
  .actor-4 {
    ${t.actor4?`fill: ${t.actor4}`:""};
  }
  .actor-5 {
    ${t.actor5?`fill: ${t.actor5}`:""};
  }
  ${gt()}
`,"getStyles"),zt=Nt,D=n(function(t,e){return dt(t,e)},"drawRect"),Wt=n(function(t,e){let c=t.append("circle").attr("cx",e.cx).attr("cy",e.cy).attr("class","face").attr("r",15).attr("stroke-width",2).attr("overflow","visible"),i=t.append("g");i.append("circle").attr("cx",e.cx-15/3).attr("cy",e.cy-15/3).attr("r",1.5).attr("stroke-width",2).attr("fill","#666").attr("stroke","#666"),i.append("circle").attr("cx",e.cx+15/3).attr("cy",e.cy-15/3).attr("r",1.5).attr("stroke-width",2).attr("fill","#666").attr("stroke","#666");function f(g){let m=U().startAngle(Math.PI/2).endAngle(3*(Math.PI/2)).innerRadius(7.5).outerRadius(6.8181818181818175);g.append("path").attr("class","mouth").attr("d",m).attr("transform","translate("+e.cx+","+(e.cy+2)+")")}n(f,"smile");function u(g){let m=U().startAngle(3*Math.PI/2).endAngle(5*(Math.PI/2)).innerRadius(7.5).outerRadius(6.8181818181818175);g.append("path").attr("class","mouth").attr("d",m).attr("transform","translate("+e.cx+","+(e.cy+7)+")")}n(u,"sad");function d(g){g.append("line").attr("class","mouth").attr("stroke",2).attr("x1",e.cx-5).attr("y1",e.cy+7).attr("x2",e.cx+5).attr("y2",e.cy+7).attr("class","mouth").attr("stroke-width","1px").attr("stroke","#666")}return n(d,"ambivalent"),e.score>3?f(i):e.score<3?u(i):d(i),c},"drawFace"),vt=n(function(t,e){let s=t.append("circle");return s.attr("cx",e.cx),s.attr("cy",e.cy),s.attr("class","actor-"+e.pos),s.attr("fill",e.fill),s.attr("stroke",e.stroke),s.attr("r",e.r),s.class!==void 0&&s.attr("class",s.class),e.title!==void 0&&s.append("title").text(e.title),s},"drawCircle"),wt=n(function(t,e){return pt(t,e)},"drawText"),Ot=n(function(t,e){function s(i,f,u,d,g){return i+","+f+" "+(i+u)+","+f+" "+(i+u)+","+(f+d-g)+" "+(i+u-g*1.2)+","+(f+d)+" "+i+","+(f+d)}n(s,"genPoints");let c=t.append("polygon");c.attr("points",s(e.x,e.y,50,20,7)),c.attr("class","labelBox"),e.y=e.y+e.labelMargin,e.x=e.x+.5*e.labelMargin,wt(t,e)},"drawLabel"),Yt=n(function(t,e,s){let c=t.append("g"),i=Z();i.x=e.x,i.y=e.y,i.fill=e.fill,i.width=s.width*e.taskCount+s.diagramMarginX*(e.taskCount-1),i.height=s.height,i.class="journey-section section-type-"+e.num,i.rx=3,i.ry=3,D(c,i),Tt(s)(e.text,c,i.x,i.y,i.width,i.height,{class:"journey-section section-type-"+e.num},s,e.colour)},"drawSection"),kt=-1,qt=n(function(t,e,s){let c=e.x+s.width/2,i=t.append("g");kt++;let f=300+5*30;i.append("line").attr("id","task"+kt).attr("x1",c).attr("y1",e.y).attr("x2",c).attr("y2",f).attr("class","task-line").attr("stroke-width","1px").attr("stroke-dasharray","4 2").attr("stroke","#666"),Wt(i,{cx:c,cy:300+(5-e.score)*30,score:e.score});let u=Z();u.x=e.x,u.y=e.y,u.fill=e.fill,u.width=s.width,u.height=s.height,u.class="task task-type-"+e.num,u.rx=3,u.ry=3,D(i,u);let d=e.x+14;e.people.forEach(g=>{let m=e.actors[g].color,x={cx:d,cy:e.y,r:7,fill:m,stroke:"#000",title:g,pos:e.actors[g].position};vt(i,x),d+=10}),Tt(s)(e.task,i,u.x,u.y,u.width,u.height,{class:"task"},s,e.colour)},"drawTask"),Xt=n(function(t,e){ft(t,e)},"drawBackgroundRect"),Tt=function(){function t(i,f,u,d,g,m,x,h){let r=f.append("text").attr("x",u+g/2).attr("y",d+m/2+5).style("font-color",h).style("text-anchor","middle").text(i);c(r,x)}n(t,"byText");function e(i,f,u,d,g,m,x,h,r){let{taskFontSize:a,taskFontFamily:l}=h,y=i.split(/<br\s*\/?>/gi);for(let p=0;p<y.length;p++){let o=p*a-a*(y.length-1)/2,v=f.append("text").attr("x",u+g/2).attr("y",d).attr("fill",r).style("text-anchor","middle").style("font-size",a).style("font-family",l);v.append("tspan").attr("x",u+g/2).attr("dy",o).text(y[p]),v.attr("y",d+m/2).attr("dominant-baseline","central").attr("alignment-baseline","central"),c(v,x)}}n(e,"byTspan");function s(i,f,u,d,g,m,x,h){let r=f.append("switch"),l=r.append("foreignObject").attr("x",u).attr("y",d).attr("width",g).attr("height",m).attr("position","fixed").append("xhtml:div").style("display","table").style("height","100%").style("width","100%");l.append("div").attr("class","label").style("display","table-cell").style("text-align","center").style("vertical-align","middle").text(i),e(i,r,u,d,g,m,x,h),c(l,x)}n(s,"byFo");function c(i,f){for(let u in f)u in f&&i.attr(u,f[u])}return n(c,"_setTextAttrs"),function(i){return i.textPlacement==="fo"?s:i.textPlacement==="old"?t:e}}(),Gt=n(function(t){t.append("defs").append("marker").attr("id","arrowhead").attr("refX",5).attr("refY",2).attr("markerWidth",6).attr("markerHeight",4).attr("orient","auto").append("path").attr("d","M 0,0 V 4 L6,2 Z")},"initGraphics"),j={drawRect:D,drawCircle:vt,drawSection:Yt,drawText:wt,drawLabel:Ot,drawTask:qt,drawBackgroundRect:Xt,initGraphics:Gt},Ht=n(function(t){Object.keys(t).forEach(function(s){$[s]=t[s]})},"setConf"),E={},O=0;function St(t){let e=F().journey,s=e.maxLabelWidth;O=0;let c=60;Object.keys(E).forEach(i=>{let f=E[i].color,u={cx:20,cy:c,r:7,fill:f,stroke:"#000",pos:E[i].position};j.drawCircle(t,u);let d=t.append("text").attr("visibility","hidden").text(i),g=d.node().getBoundingClientRect().width;d.remove();let m=[];if(g<=s)m=[i];else{let x=i.split(" "),h="";d=t.append("text").attr("visibility","hidden"),x.forEach(r=>{let a=h?`${h} ${r}`:r;if(d.text(a),d.node().getBoundingClientRect().width>s){if(h&&m.push(h),h=r,d.text(r),d.node().getBoundingClientRect().width>s){let y="";for(let p of r)y+=p,d.text(y+"-"),d.node().getBoundingClientRect().width>s&&(m.push(y.slice(0,-1)+"-"),y=p);h=y}}else h=a}),h&&m.push(h),d.remove()}m.forEach((x,h)=>{let r={x:40,y:c+7+h*20,fill:"#666",text:x,textMargin:e.boxTextMargin??5},l=j.drawText(t,r).node().getBoundingClientRect().width;l>O&&l>e.leftMargin-l&&(O=l)}),c+=Math.max(20,m.length*20)})}n(St,"drawActorLegend");var $=F().journey,P=0,Ut=n(function(t,e,s,c){let i=F(),f=i.journey.titleColor,u=i.journey.titleFontSize,d=i.journey.titleFontFamily,g=i.securityLevel,m;g==="sandbox"&&(m=W("#i"+e));let x=g==="sandbox"?W(m.nodes()[0].contentDocument.body):W("body");S.init();let h=x.select("#"+e);j.initGraphics(h);let r=c.db.getTasks(),a=c.db.getDiagramTitle(),l=c.db.getActors();for(let C in E)delete E[C];let y=0;l.forEach(C=>{E[C]={color:$.actorColours[y%$.actorColours.length],position:y},y++}),St(h),P=$.leftMargin+O,S.insert(0,0,P,Object.keys(E).length*50),Zt(h,r,0);let p=S.getBounds();a&&h.append("text").text(a).attr("x",P).attr("font-size",u).attr("font-weight","bold").attr("y",25).attr("fill",f).attr("font-family",d);let o=p.stopy-p.starty+2*$.diagramMarginY,v=P+p.stopx+2*$.diagramMarginX;st(h,o,v,$.useMaxWidth),h.append("line").attr("x1",P).attr("y1",$.height*4).attr("x2",v-P-4).attr("y2",$.height*4).attr("stroke-width",4).attr("stroke","black").attr("marker-end","url(#arrowhead)");let k=a?70:0;h.attr("viewBox",`${p.startx} -25 ${v} ${o+k}`),h.attr("preserveAspectRatio","xMinYMin meet"),h.attr("height",o+k+25)},"draw"),S={data:{startx:void 0,stopx:void 0,starty:void 0,stopy:void 0},verticalPos:0,sequenceItems:[],init:n(function(){this.sequenceItems=[],this.data={startx:void 0,stopx:void 0,starty:void 0,stopy:void 0},this.verticalPos=0},"init"),updateVal:n(function(t,e,s,c){t[e]===void 0?t[e]=s:t[e]=c(s,t[e])},"updateVal"),updateBounds:n(function(t,e,s,c){let i=F().journey,f=this,u=0;function d(g){return n(function(x){u++;let h=f.sequenceItems.length-u+1;f.updateVal(x,"starty",e-h*i.boxMargin,Math.min),f.updateVal(x,"stopy",c+h*i.boxMargin,Math.max),f.updateVal(S.data,"startx",t-h*i.boxMargin,Math.min),f.updateVal(S.data,"stopx",s+h*i.boxMargin,Math.max),g!=="activation"&&(f.updateVal(x,"startx",t-h*i.boxMargin,Math.min),f.updateVal(x,"stopx",s+h*i.boxMargin,Math.max),f.updateVal(S.data,"starty",e-h*i.boxMargin,Math.min),f.updateVal(S.data,"stopy",c+h*i.boxMargin,Math.max))},"updateItemBounds")}n(d,"updateFn"),this.sequenceItems.forEach(d())},"updateBounds"),insert:n(function(t,e,s,c){let i=Math.min(t,s),f=Math.max(t,s),u=Math.min(e,c),d=Math.max(e,c);this.updateVal(S.data,"startx",i,Math.min),this.updateVal(S.data,"starty",u,Math.min),this.updateVal(S.data,"stopx",f,Math.max),this.updateVal(S.data,"stopy",d,Math.max),this.updateBounds(i,u,f,d)},"insert"),bumpVerticalPos:n(function(t){this.verticalPos=this.verticalPos+t,this.data.stopy=this.verticalPos},"bumpVerticalPos"),getVerticalPos:n(function(){return this.verticalPos},"getVerticalPos"),getBounds:n(function(){return this.data},"getBounds")},J=$.sectionFills,bt=$.sectionColours,Zt=n(function(t,e,s){let c=F().journey,i="",f=c.height*2+c.diagramMarginY,u=s+f,d=0,g="#CCC",m="black",x=0;for(let[h,r]of e.entries()){if(i!==r.section){g=J[d%J.length],x=d%J.length,m=bt[d%bt.length];let l=0,y=r.section;for(let o=h;o<e.length&&e[o].section==y;o++)l=l+1;let p={x:h*c.taskMargin+h*c.width+P,y:50,text:r.section,fill:g,num:x,colour:m,taskCount:l};j.drawSection(t,p,c),i=r.section,d++}let a=r.people.reduce((l,y)=>(E[y]&&(l[y]=E[y]),l),{});r.x=h*c.taskMargin+h*c.width+P,r.y=u,r.width=c.diagramMarginX,r.height=c.diagramMarginY,r.colour=m,r.fill=g,r.num=x,r.actors=a,j.drawTask(t,r,c),S.insert(r.x,r.y,r.x+r.width+c.taskMargin,300+5*30)}},"drawTasks"),_t={setConf:Ht,draw:Ut},ie={parser:Pt,db:xt,renderer:_t,styles:zt,init:n(t=>{_t.setConf(t.journey),xt.clear()},"init")};export{ie as diagram};
